#include "path_calc.h"
#include "config.h"

#include <algorithm>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <set>
#include <cassert>
#include <queue>

BoardProperty BoardProp;

static double distance(const Point& p1, const Point& p2)
{
	auto offset = p1 - p2;
	return sqrt(offset.x * offset.x + offset.y * offset.y);
}
class Segment
{
public:
	Segment(const Point& p1, const Point& p2) :m_p1(p1), m_p2(p2)
	{
		auto offset = p2 - p1;
		m_k = offset.y / (double)offset.x;
		m_b = p1.y - m_k * p1.x;
	}
	inline double k() const { return m_k; }
	inline double b() const { return m_b; }
	Point intersectionAsLine(const Segment& seg) const 
	{
		auto x = (m_b - seg.m_b) / (seg.m_k - m_k);
		auto y = m_k * x + m_b;
		return { x,y };
	}
	double minDistToSeg(const Segment& seg) const 
	{
		auto minx = std::min(m_p1.x, m_p2.x);
		auto maxx = std::max(m_p1.x, m_p2.x);

		auto ominx = std::min(seg.m_p1.x, seg.m_p2.x);
		auto omaxx = std::max(seg.m_p1.x, seg.m_p2.x);
		if (minx> omaxx || maxx < ominx) {
			return DBL_MAX;
		}



	}
private:
	Point m_p1, m_p2;
	double m_k, m_b;
};

// l1: p1 p2
// l2: p3 p4
bool isSegmentIntersect(const Point& p1, const Point& p2, const Point& p3, const Point& p4)
{
	assert(p1.x != p2.x && p3.x != p4.x);	//б��һ������
	if (std::max<double>(p1.x, p2.x) < std::min<double>(p3.x, p4.x) || std::min<double>(p1.x, p2.x) > std::max<double>(p3.x, p4.x))
	{
		return false;	// x����û���ص�����
	}
	auto loffset1 = p2 - p1;
	auto loffset2 = p4 - p3;
	if (loffset1.x * loffset2.y == loffset1.y * loffset2.x) {
		return false;	// ƽ��
	}
	Segment l1(p1, p2);
	Segment l2(p3, p4);
	Point intersection = l1.intersectionAsLine(l2);
	if (intersection.x >= std::min<double>(p1.x, p2.x) && intersection.x <= std::max<double>(p1.x, p2.x) &&
		intersection.x >= std::min<double>(p3.x, p4.x) && intersection.x <= std::max<double>(p3.x, p4.x))
	{
		return true;
	}
	return false;
}
// speed up speed down

class PathIntersector
{
public:
	typedef double start;
	typedef double end;
	class Path
	{
		enum Type {Segment,Curve};
		Type type;
		std::pair<start, end> scope; // start �Ǵ�ֱ�ٶ�Ϊ��ĵ㣬ʵ�ʹ켣���� start->end
		explicit Path(Type t, const std::pair<start, end>& s) :type(t), scope(s) {};
	};
	std::vector<Path> path1, path2;
	bool isIntersected()const {
		for (const auto& ps1 : path1) {
			for (const auto& ps2 : path2) {
				;;
			
			}
		}
		return true;
	}
private:
	// �б�ʽb^2-4ac
	bool segSeg() { ;; }
	bool segCur() { ;; }
	bool curCur() { ;; }

};
static bool isCurveIntersect(const Point& p1, const Point& p2, const Point& p3, const Point& p4)
{
	static const double Vmax = 20;
	static const double a = 40;
	static const double Vh = 10;

	// max box
	auto dt = Vmax / a;
	auto dx = Vh * dt;
	auto dy = a * dt * dt / 2;

	PathIntersector tool;
	if (std::abs(p1.x - p2.x) <= 2 * dx) {
		// ���ټ�������
	}
	if (std::abs(p3.x - p4.x) <= 2 * dx)
	{
		// ���ټ�������
	}

	// ���� ���� ����
	return tool.isIntersected();
}

static std::vector<Points> bySweepLine(const Points& points, const std::vector<std::vector<int>>& paths);

// points Ӧ������Ȼ����ģ���x�Ӵ���С�����Ǿ���������

static bool isAccessable(const Point& p1, const Point& p2);

std::vector<std::vector<double>> GraphGenerator::graphicGenerate(const Points& points)
{
	std::vector<std::vector<double>> graphic(points.size(), std::vector<double>(points.size(), -1));
	for (int i = 0; i < points.size();i++) {
		auto& p1 = points[i];
		for (int j = 0; j < points.size();j++)
		{
			if (i == j) {
				continue;
			}
			auto& p2 = points[j];
			if (!isAccessable(p1, p2)) {
				continue;
			}
			graphic[i][j] = distance(p1, p2);
#ifdef DEBUG
#ifdef FULL_PATH ON
			cv::arrowedLine(img, point2cvPoint(points[i]), point2cvPoint(points[j]), cv::Scalar(0, 255, 255), 1);
#endif
#endif
		}
	}
	return graphic;
}

class DistComp
{
	Point p;
	const Points* points;
public:
	DistComp(const Points& points, const Point& p) :points(&points), p(p) {}
	bool operator()(int i, int j) {
		return distance(p, (*points)[i]) > distance(p, (*points)[j]);
	}
};

std::unordered_map<int, std::pair<int, std::vector<int>>> getMaxDepthPath(int& maxIndex, int& maxDepth,
	const Points& points, const std::unordered_set<int>& usedPoints,
	const std::vector<std::vector<double>>& graphic)
{
	maxIndex = -1;
	maxDepth = 0;
	std::unordered_map<int, std::pair<int, std::vector<int>>> depthPath;   //<index,<max_depth,path>>, ��indexΪ��������·��
	for (int i = points.size() - 1;i >= 0;i--)
	{
		if (usedPoints.find(i) != usedPoints.end()) {
			continue;
		}
		int curMaxDepth = 0;
		int curMaxIndex = -1;
		std::priority_queue<int, std::vector<int>, DistComp> depthIndexes(DistComp(points, points[i]));
		for (int j = i + 1; j < points.size();j++)
		{
			if (usedPoints.find(j) != usedPoints.end()) {
				continue;
			}
			if (graphic[i][j] < 0) {
				continue;
			}
			//assert(depthPath.find(j) != depthPath.end());
			if (curMaxDepth < depthPath[j].first) {
				curMaxDepth = depthPath[j].first;
				curMaxIndex = j;
				std::priority_queue<int, std::vector<int>, DistComp> newPQ(DistComp(points, points[i]));
				newPQ.push(j);
				depthIndexes = newPQ;
			}
			else if (curMaxDepth == depthPath[j].first) {
				depthIndexes.push(j);
			}
		}
		std::vector<int> path{ i };
		if (depthIndexes.size()) {
			const auto& prePath = depthPath[depthIndexes.top()].second;
			path.insert(path.end(), prePath.begin(), prePath.end());
		}
		depthPath[i] = { curMaxDepth += 1, path };
		if (maxDepth < curMaxDepth) {
			maxDepth = curMaxDepth;
			maxIndex = i;
		}
	};
	return depthPath;

};

std::vector<Points> GraphGenerator::generate(const Points& points)
{
	if (points.empty()) {
		return {};
	}
	std::vector<std::vector<double>> graphic = std::move(graphicGenerate(points));
	std::unordered_set<int> usedPoints;
	int maxIndex = -1;
	int maxDepth = 0;
	std::vector<std::vector<int>> paths;
	for (int i = 0;i < CAMERA_COUNT;i++)
	{
		auto depthPath = std::move(getMaxDepthPath(maxIndex, maxDepth, points, usedPoints, graphic));
		paths.emplace_back(depthPath[maxIndex].second);
		if (paths.back().size() > 1) {
			for (int i = 1; i < paths.back().size(); i++)
			{
#if HANDLE_CROSS
#else
				cv::line(img, point2cvPoint(points[paths.back()[i - 1]]), point2cvPoint(points[paths.back()[i]]), cv::Scalar(0, 255, 255), 1, cv::LINE_AA);
#endif
			}
		}
		usedPoints.insert(paths.back().begin(), paths.back().end());
	}


	// �ཻ�㴦��
	return bySweepLine(points, paths);
}

// �Ե�ǰ�����˶��ٶȣ���������ٶ��£��Ƿ���Դ�p1��p2
bool isAccessable(const Point& p1, const Point& p2)
{
	if (p2.x >= p1.x) {
		return false;
	}
	if (BoardProp.speed == 0) {
		assert(false);	// ��ֹ����������һ���߼���Ӧ�ò�������
		return true;
	}

	Offset offset = p1 - p2;
	auto t = offset.x / BoardProp.speed;
	return MAX_ACCELERATION * t * t / 4 > std::abs(offset.y);
	/*
��Ҫ���ǵĳ�����
	1������
	2���᲻�����˶������з������仯
*/
}

bool GraphGenerator::isAccessable_debug(const Point& p1, const Point& p2) {
	return isAccessable
	(p1, p2);
}

struct Node {
	Node* next = nullptr;
	const Point* pp;
	Node(const Point& p) :pp(&p) {}
	~Node() { next = nullptr; }
	operator Point() const { return *pp; }
	bool operator<(const Node& node) const { return pp->x < node.pp->x; }
};

class LessComp
{
public:
	bool operator()(const Node* node1, const Node* node2) {
		return *node1 < *node2;
	}
};
class GreaterComp
{
public:
	bool operator()(const Node* node1, const Node* node2) {
		assert(node1->next && node2->next);
		return node1->next->pp->x > node2->next->pp->x;
	}
};

#if 1
//debug
#include "opencv/include/opencv2/opencv.hpp"
#include <iostream>

static void drawDotLine(cv::InputOutputArray img, cv::Point pt1, cv::Point pt2, const cv::Scalar& color)
{
	int dx = pt2.x - pt1.x;
	int dy = pt2.y - pt1.y;
	float len = std::sqrt(dx * dx + dy * dy);
	float stepX = dx / len;
	float stepY = dy / len;

	for (float t = 0; t < len; t += 20) {

		cv::Point p(pt1.x + stepX * t, pt1.y + stepY * t);
		cv::circle(img, p, 1, color, -1);
	}

}

static int num = 0;
void showPath(
	const std::vector<Node*>& headers,
	Node* curNode,
	const std::unordered_set<Node*>& popedNodes,
	const std::unordered_set<Node*>& workingNodes)
{
	std::cout << "paint tag: " << num++ << std::endl;
	cv::Mat img = cv::Mat::zeros(1080, 2048, CV_8UC3);
	cv::arrowedLine(img, cv::Point(0, 0), cv::Point(512, 0), cv::Scalar(255, 255, 255), 1);
	cv::arrowedLine(img, cv::Point(0, 0), cv::Point(0, 512), cv::Scalar(255, 255, 255), 1);
	cv::putText(img, cv::String("X"), cv::Point(470, 50), cv::FONT_HERSHEY_COMPLEX, 1, cv::Scalar(255, 255, 255));
	cv::putText(img, cv::String("Y"), cv::Point(10, 500), cv::FONT_HERSHEY_COMPLEX, 1, cv::Scalar(255, 255, 255));
	drawDotLine(img, cv::Point(curNode->pp->x, 0), cv::Point(curNode->pp->x, 1080), cv::Scalar(0, 0, 255));

	for (auto node : headers) {
		while (node->next) {
			cv::circle(img, cv::Point(node->pp->x, node->pp->y), 3, cv::Scalar(255, 0, 0), -1);
			cv::Scalar scalar = cv::Scalar(0, 255, 255);
			if (node == curNode) {
				scalar = cv::Scalar(0, 255, 0);
			}
			else if (popedNodes.count(node))
			{
				scalar = cv::Scalar(100, 100, 100);
			}
			else if (workingNodes.count(node))
			{
				scalar = cv::Scalar(0, 0, 255);
			}

			cv::line(img, cv::Point(node->pp->x, node->pp->y), cv::Point(node->next->pp->x, node->next->pp->y), scalar, 1, cv::LINE_AA);
			node = node->next;
		}
		cv::circle(img, cv::Point(node->pp->x, node->pp->y), 3, cv::Scalar(255, 0, 0), -1);
	}
	cv::imshow("debug", img);
	cv::waitKey(0);
}

#endif

bool keepNoIntersection(std::list<Node*>& nl,
	std::priority_queue<Node*, std::vector<Node*>, GreaterComp>& popedNodes,
	std::unordered_set<Node*>& workingNodes,
	std::set<Node*>& recycleNodeSet
) {
	auto recycleNodes = [&](Node* node)
		{
			if (!isAccessable(*node, *(node->next))) {
				Node* nnode = node->next;
				node->next = nnode->next;
				nnode->next = nullptr;
				recycleNodeSet.insert(nnode);
			}
		};

	bool changed = false;
	for (auto it = nl.begin(); it != nl.end();it++) {
		if (!(*it)->next) { continue; }
		for (auto jt = nl.begin();jt != nl.end();jt++) {
			if (!(*jt)->next) { continue; }
			if (it == jt) { continue; }
			if ((*it)->next->pp->x == (*jt)->pp->x ||
				(*jt)->next->pp->x == (*it)->pp->x) {
				continue;
			}
			Node* node1 = *it;
			Node* node2 = *jt;
			if (isSegmentIntersect(*node1, *(node1->next), *node2, *(node2->next)))
			{
				assert(node1 != node2->next && node2 != node1->next);
				auto next1 = node1->next;
				node1->next = node2->next;
				node2->next = next1;
				changed = true;
				std::list<Node*> freeNodes;
				recycleNodes(node1);
				recycleNodes(node2);

				// ��������Ϊ�����±ߣ� ֮ǰ�����ı���Ҫ�����ж�
				std::list<Node*> toFetchBacks;
				while (popedNodes.size()) {
					Node* popedNode = popedNodes.top();
					assert(popedNode->next);
					if (std::max<double>(node1->pp->x, node2->pp->x) >= popedNode->next->pp->x) {
						toFetchBacks.push_front(popedNode);
						workingNodes.insert(popedNode);
						popedNodes.pop();
						continue;
					}
					break;
				}
				if (toFetchBacks.size()) {
					nl.insert(nl.begin(), toFetchBacks.begin(), toFetchBacks.end());
					return true;
				}
			}
			if (isCurveIntersect(*node1, *(node1->next), *node2, *(node2->next))) {}
		}
	}
	return changed;
};

static Node* vec2list(std::priority_queue<Node*, std::vector<Node*>, LessComp>& pq, const Points& points, const std::vector<int>& path)
{
	if (path.empty()) {
		return nullptr;
	}
	auto head = new Node(points[path.front()]);
	pq.push(head);
	auto cp = head;
	for (int j = 1; j < path.size(); j++) {
		auto node = new Node(points[path[j]]);
		pq.push(node);
		cp->next = node;
		cp = node;
	}
	return head;
}

static std::vector<Points> bySweepLine(const Points& points, const std::vector<std::vector<int>>& paths)
{
	std::priority_queue<Node*, std::vector<Node*>, LessComp> pq;
	std::vector<Node*> roots;
	for (int i = 0; i < paths.size();i++)
	{
		if (Node* root = vec2list(pq, points, paths[i]))
		{
			roots.push_back(root);
		}
	}
	std::list<Node*> nl;	// x�Ӵ�С����
	std::priority_queue<Node*, std::vector<Node*>, GreaterComp> popedNodes;
	std::unordered_set<Node*> popedNodeSet;		// for debug
	std::unordered_set<Node*> workingNodes;		// for debug
	std::set<Node*> recycleNodeSet;			// �����ڵ�

	while (pq.size())
	{
		auto node = pq.top();
		pq.pop();
		if (recycleNodeSet.count(node)) {
			continue;
		}
		workingNodes.insert(node);
		nl.push_back(node);
		// ���洦��
		//showPath(roots, node, popedNodeSet, workingNodes);
		while (keepNoIntersection(nl, popedNodes, workingNodes, recycleNodeSet));
		//showPath(roots, node, popedNodeSet, workingNodes);

		// �����������н���ı�
		// method 0, do nothing

		// method 1,ɨ����
		for (auto it = nl.begin();it != nl.end();)
		{
			if ((*it)->next == nullptr) {	// node �Ǳ���Ϊ��next�����ӵıߣ�ĩβ�ڵ㲻ά��
				it = nl.erase(it);
				continue;
			}
			if ((*it)->next->pp->x > node->pp->x) {
				popedNodes.push(*it);
				popedNodeSet.insert(*it);
				workingNodes.erase(*it);
				it = nl.erase(it);
				continue;
			}
			break;
			it++;
		}

		// method 2, �߶���
	}
	std::vector<Points> ret;
	for (auto it = roots.begin(); it != roots.end(); it++)
	{
		Points retPath;
		Node* node = *it;
		while (node) {
			retPath.emplace_back(*node);
			auto next = node->next;
			delete node;
			node = next;
		}
		ret.emplace_back(std::move(retPath));
	}
	for (auto node : recycleNodeSet) {
		delete node;
	}
	return ret;

}
