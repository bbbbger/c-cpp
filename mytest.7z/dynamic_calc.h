#pragma once


void dynamic_test();