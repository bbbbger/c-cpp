#include <iostream>
#include "fsm.hpp"
#include <Windows.h>
#include <cassert>
#include <unordered_set>
#include <unordered_map>
#include <set>
#include <chrono>
#include <algorithm>

#include "path_calc.h"
#include "config.h"

#include "opencv2/opencv.hpp"
#include "opencv2/core/hal/interface.h"


// ɨ���߲���
// #include "sweepLine.h"


class Camera
{
	enum  state { closing, waiting, moving, ready, working };
	enum  action {};


public:
	Camera();


private:
	fsm::stack stk;
};

Camera::Camera()
{
	// ����
	stk.on(state::closing, state::waiting) = [](const fsm::args& args) {};
	// �ػ�
	stk.on(state::waiting, state::closing) = [](const fsm::args& args) {};
	// ��������Ҫ�ƶ���Ԥ��λ��
	stk.on(state::waiting, state::moving) = [](const fsm::args& args) {};
	// �����񣬵�ǰλ�ü���Ԥ��λ��
	stk.on(state::waiting, state::ready) = [](const fsm::args& args) {};
	// �ƶ���Ԥ��λ��
	stk.on(state::moving, state::ready) = [](const fsm::args& args) {};
	// ����ͼ��������涨λ�ã�׼������
	stk.on(state::ready, state::working) = [](const fsm::args& args) {};
	// ������ϣ��������
	stk.on(state::working, state::waiting) = [](const fsm::args& args) {};
}

#ifdef DEBUG
static std::vector<cv::Point> points2cvPoints(const Points& points);
static cv::Point point2cvPoint(const Point& poiunt);
#endif

static cv::Point point2cvPoint(const Point& point)
{
	return { static_cast<int>(point.x),static_cast<int>(point.y) };
}

static std::vector<cv::Point> points2cvPoints(const Points& points)
{
	std::vector<cv::Point> ret;
	for (const auto& p : points) {
		ret.emplace_back(std::move(point2cvPoint(p)));
	}
	return ret;
}


template<class ostream>
ostream& operator<<(ostream& stream, const Point& p) {
	return stream << "{" << std::to_string(p.x) << "," << std::to_string(p.y) << "}";
}

#include <fstream>
class LOG {

	const char* path = "log.txt";
	std::fstream fs;
public:
	static LOG& log();
	~LOG();
	LOG& operator<<(const std::string& log);
private:
	LOG();
	static LOG* _LOG;
};
LOG* LOG::_LOG = nullptr;

LOG& LOG::log()
{
	if (!_LOG)
	{
		_LOG = new LOG();
	}
	return *_LOG;
}

LOG::LOG()
{
	fs.open(path, std::ios_base::app | std::ios_base::out);
	if (fs.fail()) {
		std::cout << "error on opening file" << std::endl;
	}
}
LOG::~LOG()
{
	fs.close();
}


LOG& LOG::operator<<(const std::string& log)
{
	fs << log;
	return *this;
}

static void drawPoints(cv::Mat img, const Points& points)
{
	for (const auto& p : points2cvPoints(points))
	{
		cv::circle(img, p, 3, cv::Scalar(0, 0, 255), -1);
		std::stringstream ss;
#if PRINT_POS 
		ss << "(" << p.x << ", " << p.y << ")";
		cv::putText(img, ss.str(), p, cv::FONT_HERSHEY_COMPLEX, 0.5, cv::Scalar(255, 255, 255));
#endif
	}
}

static cv::Point cvPoint(const Point& p) {
	return cv::Point(static_cast<int>(p.x), static_cast<int>(p.y));
};

static void drawPaths(cv::Mat& img, const std::vector<Points>& paths)
{
	int pointSize = 0;
	for (auto path : paths)
	{
		pointSize += path.size();
		int seq = 1;
		for (int i = 1; i < path.size(); i++)
		{
#if PRINT_POS
#elif PRINT_SEQUENCE
			std::stringstream ss;
			ss << i;
			cv::putText(img, ss.str(), point2cvPoint(path[i]), cv::FONT_HERSHEY_COMPLEX, 0.5, cv::Scalar(255, 255, 255));
#endif		
			cv::line(img, cvPoint(path[i]), cvPoint(path[i - 1]), cv::Scalar(0, 255, 0), 1, cv::LINE_AA);
		}

	}
	std::cout << "checked points size: " << pointSize << std::endl;
}

int main()
{
#if 0
	cd_player cd;
	std::cout << "[" << cd.fsm.get_state() << "] ";
	std::cout << "(o)pen lid/(c)lose lid, (i)nsert cd/(e)ject cd, (p)lay/(s)top cd? ";
	for (;;) {
		char cmd;
		std::cin >> cmd;

		switch (cmd) {
		case 'p': cd.fsm.command(play, 1 + rand() % 10); break;
		case 'o': cd.fsm.command(open); break;
		case 'c': cd.fsm.command(close); break;
		case 's': cd.fsm.command(stop); break;
		case 'i': cd.fsm.command(insert); break;
		case 'e': cd.fsm.command(eject); break;
		default: std::cout << "what?" << std::endl;
		}
	}
#endif
#if 0
	ant_t ant;
	for (int i = 0; i < 12000; ++i) {
		Sleep(0.3);
		if (0 == rand() % 10000) {
			ant.fsm.push(defending);
		}
		ant.fsm.command(tick);
	}
#endif

#define TEST 0
#if TEST
	Point p1{ 401, 341 };
	Point p2{ 338, 704 };
	Point p3{ 292, 502 };
	Point p4{ 435, 736 };
	assert(isSegmentIntersect(p1, p2, p3, p4));
#else
	//Points points{ {5,6},{4,6},{4,5},{4,2},{3,4},{3,3} ,{3,2},{3,0},{2,5},{2,2},{1,6},{1,4},{1,1},{0,3},{0,2} };
	//Points points{ {9,4},{8,4},{7,4},{7,3},{4,4} ,{4,5},{1,4},{1,3} };
	Points points;
	std::set<Point> pointSet;
	auto seed = time(NULL);
	std::cout << "seed: " << seed << std::endl;
	//seed/spped  1748231591/1000 1748235872/50
	srand(seed);
	auto preStart = std::chrono::system_clock::now();
	auto pre_t = std::chrono::system_clock::to_time_t(preStart);

	const int W = 2048;
	const int H = 1080;

	for (int i = 0;i < POINT_SIZE;i++)
	{
		Point p{ static_cast<double>(rand() % W), static_cast<double>(rand() % H) };
		pointSet.emplace(std::move(p));
	}
	points.assign(pointSet.begin(), pointSet.end());
	std::cout << "Point size: " << points.size() << std::endl;
	std::cout << "Camera Count: " << CAMERA_COUNT << std::endl;


	auto& log = LOG::log();
	log << "-------start: " << std::ctime(&pre_t);
	for (const auto& p : points)
	{
		log << p;
	}
	std::sort(points.begin(), points.end(), std::greater<>());
	auto preEnd = std::chrono::system_clock::now();
	std::cout << "pre duration: " << std::chrono::duration_cast<std::chrono::milliseconds>(preEnd - preStart).count() << "ms" << std::endl;


	auto start = std::chrono::system_clock::now();
	GraphGenerator generator;
	auto paths = generator.generate(points);
	auto end = std::chrono::system_clock::now();
	std::cout << "duration: " << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << "ms" << std::endl;
	delete& log;

	// draw
	cv::Mat img = cv::Mat::zeros(1080, 2048, CV_8UC3);

	cv::line(img, cv::Point(0, 0), cv::Point(1800, 0), cv::Scalar(255, 255, 255), 1);
	cv::line(img, cv::Point(0, 0), cv::Point(0, 800), cv::Scalar(255, 255, 255), 1);
	cv::arrowedLine(img, cv::Point(1800, 0), cv::Point(2000, 0), cv::Scalar(255, 255, 255), 1);
	cv::arrowedLine(img, cv::Point(0, 800), cv::Point(0, 1000), cv::Scalar(255, 255, 255), 1);

	cv::putText(img, cv::String("X"), cv::Point(2000, 50), cv::FONT_HERSHEY_COMPLEX, 1, cv::Scalar(255, 255, 255));
	cv::putText(img, cv::String("Y"), cv::Point(10, 1040), cv::FONT_HERSHEY_COMPLEX, 1, cv::Scalar(255, 255, 255));

	drawPoints(img, points);
	drawPaths(img, paths);
#if 1	// assert test
#if 1	// ���·�������ཻ
	for (int i = 0; i < paths.size(); i++)
	{
		for (int j = i + 1; i != j && j < paths.size();j++) {
			auto& path1 = paths[i];
			auto& path2 = paths[j];


			for (int m = 1; m < path1.size();m++) {
				for (int n = 1; n < path2.size(); n++) {
					assert(!isSegmentIntersect(path1[m], path1[m - 1], path2[n], path2[n - 1]));
				}
			}
		}
	}
#endif
#if 1	// ÿ��·�����ǿɵ����
	for (const auto& path : paths)
	{
		for (int i = 1; i < path.size(); i++) {
			assert(generator.isAccessable_debug(path[i - 1], path[i]));
		}
	}
#endif 
#endif

	cv::imshow("Created Image", img);
	cv::waitKey(0);  // ��������رմ���

#endif
}


class SimpleTrace {
	

};