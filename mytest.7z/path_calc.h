#pragma once
#include <vector>

struct Point
{
	double x;
	double y;
	//bool operator<(const Point& point) const { return x < point.x ? true : (x == point.x ? y < point.y : false); }
	bool operator<(const Point& point) const { return x < point.x; }
	bool operator>(const Point& point) const { return x > point.x; }
	bool operator==(const Point& point) const { return x == point.x && y == point.y; }
	Point operator-(const Point& point) const { return { x - point.x,y - point.y }; }

};
typedef std::vector<Point> Points;
typedef Point Offset;

class GraphGenerator
{
public:
	std::vector<Points> generate(const std::vector<Point>& points);
	bool isAccessable_debug(const Point& p1, const Point& p2);
private:

	std::vector<std::vector<double>> graphicGenerate(const Points& points);

};

bool isSegmentIntersect(const Point& p1, const Point& p2, const Point& p3, const Point& p4);