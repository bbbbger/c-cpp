#include "dynamic_calc.h"
#include <queue>


#include <thread>
#include <mutex>
#include <condition_variable>
#include <atomic>
#include <Windows.h>

struct Point {
	double x, y;
};
struct Board
{
	//double w, h;
	double x() { return 0; };
};
struct Camera {
	Point pos;
};

struct CameraRail
{


};

struct Machine {


};

class WorkState
{
public:
	//std::shared_ptr<WorkState> create() { return std::make_shared<WorkStatePrivate>(); };

};

class WorkStatePrivate :public WorkState {
	Machine machine;
	std::vector<Camera> cameras;
public:
	WorkStatePrivate() {}

};




static std::queue<Point> LRQ;
static std::queue<Point> RLQ;
std::mutex lrMtx;
std::mutex rlMtx;


std::condition_variable cv;

std::atomic<bool> engineSwitch = true;

static std::thread& pointGenerator()
{
	return std::thread([&] {
		while (engineSwitch) {
			Sleep(rand() % 10);
			std::unique_lock<std::mutex> lck(lrMtx);
			LRQ.push(Point());
		}
		});
}


// ��ײ���
struct Speed
{
	double v;
	double a;
};

//struct Path
//{
//	std::vector<std::pair<double, Speed>> path;
//
//
//};




struct CameraState
{
	Point pos;
	Speed hs;
	Speed vs;

	bool willCrash(const CameraState& state);
private:
	bool oppo;

};


bool CameraState::willCrash(const CameraState& state)
{


}


double time()
{


}

struct Path
{
	Point s;
	Point e;
	Path(const Point& p1, const Point& p2) {


	}
private:
	double a;
};

static bool willCrash(const Path& path1, const Path& path2)
{



}

struct Point
{
	double x, y;
	std::vector<Point> points;
};

/*************************************************************************************/
class GNode {
	static int seq;
	GNode(int id) :id(id) {}
public:
	int id;
	std::vector<GNode*> successors;

	static GNode* create() { return new GNode(seq++); }
};
int GNode::seq = 0;

#include <unordered_map>
#include <unordered_set>
// random graphic
class Graphic
{
	static void createPath(Graphic* graphic, GNode* node1, GNode* node2, double weight)
	{
		node1->successors.push_back(node2);
		if (weight > 0) {
			graphic->weights[std::pair<GNode*, GNode*>(node1, node2)] = 1;
		}
	}
public:
	std::unordered_map<std::pair<GNode*, GNode*>, double> weights;
	std::vector<GNode*> nodes;
	static Graphic* create(bool directed = false, bool withWeights = false, u_int seed = 0);
};

Graphic* Graphic::create(bool directed, bool withWeights, u_int seed)
{
	srand(seed);
	Graphic* graphic = new Graphic();
	u_int nodeSize = rand() % 10 + 10;
	while (nodeSize > 0) {
		graphic->nodes.emplace_back(GNode::create());
	}
	for (auto it = graphic->nodes.begin(); it != graphic->nodes.end(); it++) {
		for (auto jt = graphic->nodes.begin(); it != jt && jt != graphic->nodes.end(); jt++) {
			if (rand() % 2) {
				continue;
			}
			double weight = withWeights ? rand() % 10 + (rand() % 1000) / 1000.0 : -1;
			createPath(graphic, *it, *jt, weight);
			if (!directed) {
				createPath(graphic, *jt, *it, weight);
			}
		}
	}
	return graphic;
}

class Func
{
public:
	void bfs(GNode* node)
	{
		std::queue<GNode*> q;
		for (auto it = node->successors.begin(); it != node->successors.end(); it++) {
			// do something;
			q.emplace(*it);
		}
		while (q.size()) {
			bfs(q.front());
			q.pop();
		}
	}

	void dfs(GNode* node)
	{
		for (auto it = node->successors.begin(); it != node->successors.end(); it++) {
			// do something
			dfs(*it);
		}
	}

	void djs(GNode* node)
	{
		;
	}
};

/********************************************************************************************/
template<class T>
class TopoSort
{
	std::unordered_map<T*, std::unordered_set<T*>> graph;
	std::unordered_map<T*, int> indegree() {
		std::unordered_map<T*, int> ret;
		for (const auto& pair : graph) {
			for (auto nbr : pair.second) {
				ret[nbr]++;
			}
		}
		for (const auto& pair : graph) {
			if (ret.find(pair.first) == ret.end()) {
				ret[pair.first] = 0;
			}
		}
		return ret;
	}
	void sort() {
		auto ind = indegree();
		std::queue<T*> q;
		for (const auto& pair : ind) {
			if (pair.second == 0) {
				q.push(pair.first);
			}
		}
		std::vector<T*> topoOrder;
		while (!q.empty()) {
			T* node = q.front();
			q.pop();
			topoOrder.push_back(node);
			for (T* neighbor : graph[node]) {
				ind[neighbor]--;
				if (ind[neighbor] == 0) {
					q.push(neighbor);
				}
			}
		}
		if (topoOrder.size() != graph.size()) {
			return;	// �л�
		}
		return;	// result order: topoOrder;
	}
};


/*****************************************************************************/